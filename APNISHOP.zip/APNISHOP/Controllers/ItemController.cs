﻿using APNISHOP.Database;
using APNISHOP.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace APNISHOP.Controllers
{
    public class ItemController : Controller
    {
        public IActionResult Index()
        {
            DatabaseContextTest obj = new DatabaseContextTest();
            //{
            var query = from item in obj.Item
                        select item;
            //}
            return View(query);
        }

        public IActionResult Create()
        {
            return View();
        }

        public IActionResult Details(string id)
        {
            DatabaseContextTest obj = new DatabaseContextTest();

            var query = from item in obj.Item
                        where item.ItemId==id
                        select item;
            Item temp = query.SingleOrDefault();
            return View(temp);
        }

        public IActionResult UDetails(string id)
        {
            DatabaseContextTest obj = new DatabaseContextTest();

            var query = from item in obj.Item
                        where item.ItemId == id
                        select item;
            Item temp = query.SingleOrDefault();
            return View(temp);
        }

        public IActionResult Edit(string id)
        {
            DatabaseContextTest obj = new DatabaseContextTest();

            var query = from item in obj.Item
                        where item.ItemId == id
                        select item;
            Item temp = query.SingleOrDefault();
            return View(temp);
        }

        [HttpPost]
        public IActionResult Update(Item UpdatedData)
        {
            DatabaseContextTest obj = new DatabaseContextTest();

            var query = obj.Item.SingleOrDefault(name => name.ItemId == UpdatedData.ItemId);
            if (query != null)
            {
                query.Name = UpdatedData.Name;
                query.CurrentQuantity = UpdatedData.CurrentQuantity;
                query.CostPerUnit = UpdatedData.CostPerUnit;
                query.Category = UpdatedData.Category;
                query.Description = UpdatedData.Description;
                query.Demand = UpdatedData.Demand;

                obj.SaveChanges();
            }
            else
            {
                return RedirectToAction("Index,Home");

            }

            return RedirectToAction("LogIn", "Admin", new { area = "" });//RedirectToRoute("Home/Index");


        }

        [HttpPost]
        public IActionResult AddItem(Item obj)
        {
            using (DatabaseContextTest context = new DatabaseContextTest())
            {
                var CheckQuery= context.Item
                        .Where(name => name.ItemId == obj.ItemId)
                        .Select(name => name);  //can be single or 0
                if (CheckQuery.Count() > 0)
                {
                    return View();
                }
                //Item TempCheckQuery = CheckQuery.SingleOrDefault();
                

                Item temp = new Item()
                {
                    ItemId = obj.ItemId,
                    Name = obj.Name,
                    Category = obj.Category,
                    Description = obj.Description,
                    Demand = obj.Demand,
                    CurrentQuantity = obj.CurrentQuantity,
                    CostPerUnit = obj.CostPerUnit,
                    Rating = obj.Rating,
                     //User = tempo
                };

                context.Item.Add(temp);
                context.SaveChanges();
                

            }
            
            return RedirectToAction("Login","Admin");
            

        }
    

        public IActionResult Buy(string id)
        {
            DatabaseContextTest obj = new DatabaseContextTest();

            var query = from item in obj.Item
                        where item.ItemId == id
                        select item;
            Item temp = query.SingleOrDefault();
            return View(temp);
            //string a = UserController.UserSessionID;
        }

        public IActionResult MakeOrder(string Id)
        {
            DatabaseContextTest obj = new DatabaseContextTest();

            var query= from item in obj.Item
                       where item.ItemId == Id
                       select item;

            Item temp1 = query.FirstOrDefault();
            var query2= from item in obj.User
                        where item.UserId == UserController.UserSessionID
                        select item;
            User temp2 = query2.FirstOrDefault();

            var query3 = from item in obj.BuyOrder
                         select item;
            int counter = query3.Count();
            string TempOrderId = "B" + counter;
            BuyOrder temp=new BuyOrder()
            {
                Item=temp1,
                User=temp2,
                BuyOrderId=TempOrderId
            };

            //create Order temp model(id-->itemid,userid)
            return View(temp); //filling display post call to CheckOrder

        }

        [HttpPost]
        public IActionResult CheckOrder(BuyOrder InputObj)
        {
            int Demand= InputObj.Item.Demand;
            int currentQty = InputObj.Item.CurrentQuantity;
            int result = currentQty - Demand;
            result = result - InputObj.Qty;
            if (result < 1)
            {
                return View("~/Views/User/IncorrectLogin.cshtml");
                //error page;
            }
            else
            {
                return View("~/Views/User/CorrectLogin.cshtml");
                //add to database and render to Correct Page;
            }

            
            
        }
    }
}
