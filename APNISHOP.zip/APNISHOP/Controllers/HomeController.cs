﻿using APNISHOP.Database;
using APNISHOP.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace APNISHOP.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        //[Route("/")]
        //[Route("Home/Index")]
        public IActionResult Index()
        {
            //making single instance for databases
            using (DatabaseContextTest context = new DatabaseContextTest())
            {
                try
                {
                    var query= from user in context.Admin
                               where user.AdminId == "admin@gmail.com"
                               select user;
                    if (query.Count() <= 0)
                    {
                        query.FirstOrDefault();
                    }
                }
                catch
                {

                    Admin temp = new Admin()
                    {
                        AdminId ="Admin@gmail.com",
                        Password = "1234",
                        Contact = "03125",
                        Name = "Admin Name",

                    };

                    context.Admin.Add(temp);
                    context.SaveChanges();

                    User UserTemp = new User
                    {
                        UserId = "Ahmed@gmail.com",
                        Password = "1234",
                        Contact = "03122546789",
                        Name = "Ahmed"
                        //ProfilePicture = obj.ProfilePicture

                    };

                    context.User.Add(UserTemp);
                    context.SaveChanges();

                    Item temp2 = new Item()
                    {
                        ItemId = "I1",
                        Name = "Touch Pencil",
                        Category = "Electronics",
                        Description = "Stylus Touch Pen",
                        Demand = 34,
                        CurrentQuantity = 35,
                        CostPerUnit = 5600,
                        Rating = 5,
                        //User = UserTemp
                    };

                    context.Item.Add(temp2);
                    context.SaveChanges();


                    BuyOrder temp3 = new BuyOrder
                    {
                        BuyOrderId = "B1",
                        Item = temp2,
                        User=UserTemp,
                        Status="Cancelled",
                        Qty=10
                    };
                    context.BuyOrder.Add(temp3);
                    context.SaveChanges();

                    SellOrder temp4 = new SellOrder
                    {
                        SellOrderId= "S1",
                        ProductName="Mouse",
                        Category="Electronics",
                        Qty=10,
                        CostPerUnit=200,
                        Description="Dell Mouse",
                        User=UserTemp
                    };
                    context.SellOrder.Add(temp4);
                    context.SaveChanges();

                }


            }


            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
