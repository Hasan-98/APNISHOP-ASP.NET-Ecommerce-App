﻿using APNISHOP.Database;
using APNISHOP.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace APNISHOP.Controllers
{
    public class AdminController : Controller
    {
        static string AdminSessionID = "\0";

        [Route("Admin/Index")]
        [Route("User")]
        public IActionResult Index()
        {

            DatabaseContextTest obj = new DatabaseContextTest();
            //{
            var query = from user in obj.Admin
                        select user;
            //}
            return View(query);
        }

        public IActionResult Master()
        {
            return View();
        }


        public IActionResult Edit()
        {
            DatabaseContextTest obj = new DatabaseContextTest();

            var query = obj.Admin
                        .Where(name => name.AdminId == AdminSessionID)
                        .Select(name => name);  //can be single or 0

            Admin temp = query.Single();
            return View(temp);
        }

        public IActionResult Details()
        {
            DatabaseContextTest obj = new DatabaseContextTest();

            var query = obj.Admin
                        .Where(name => name.AdminId == AdminSessionID)
                        .Select(name => name);  //can be single or 0
            //if (query.Count() <= 0)  //safe check if that user dont exist in db
            //{
            //    return View("~/Views/User/IncorrectLogin.cshtml");
            //}

            //string UserDBPassword = query.Single(); //make it single(query contains in iquery list so make it single and convert it in single string)
            //if (Password == UserDBPassword)
            //{
            //    return View();   //Login Landing page
            //    return Redirect("Item/Index");
            //}
            Admin temp = query.Single();
            return View(temp);
        }
        public IActionResult LogOut()
        {
            AdminSessionID = "\0";
            return RedirectToAction("Index", "Home", new { area = "" });//RedirectToRoute("Home/Index");
        }

        public IActionResult LandingPage()
        {
            return View();  //login page with registeration option to register.
        }

        [HttpPost]
        public IActionResult Create(string MasterPassword)
        {
            if (MasterPassword == "master12345")
            {
                return View();
            }
            else
            {
                AdminSessionID = "\0";
                return RedirectToAction("Index", "Home", new { area = "" });//RedirectToRoute("Home/Index");

            }
        }


        [HttpPost]
        public IActionResult Update(Admin UpdatedData)
        {
            DatabaseContextTest obj = new DatabaseContextTest();

            var query = obj.Admin.SingleOrDefault(name => name.AdminId == AdminSessionID);
            if (query != null)
            {
                query.Name = UpdatedData.Name;
                query.Password = UpdatedData.Password;
                query.Contact = UpdatedData.Contact;
                obj.SaveChanges();
            }

            return RedirectToAction("LogIn");
        }

        [HttpPost]
        public IActionResult AddAdmin(Admin obj)
        {
            AdminSessionID = "\0";

            using (DatabaseContextTest context = new DatabaseContextTest())
            {
                Admin temp = new Admin()
                {
                    AdminId = obj.AdminId,
                    Password = obj.Password,
                    Contact = obj.Contact,
                    Name = obj.Name,

                };

                context.Admin.Add(temp);
                context.SaveChanges();
            }

            return RedirectToAction("Index", "Home", new { area = "" });//RedirectToRoute("Home/Index");
        }

        [HttpPost]
        public IActionResult LogInValidate(string AdminId, string Password)
        {
            //use for debuggin whether string is empty or not (Use same name as of label)
            //if(string.IsNullOrEmpty(UserId) && string.IsNullOrEmpty(Password))
            //{
            //    return View("~/Views/User/debug1.cshtml");
            //}

            DatabaseContextTest obj = new DatabaseContextTest();

            var query = obj.Admin
                        .Where(name => name.AdminId == AdminId)
                        .Select(name => name.Password);  //can be single or 0
            if (query.Count() <= 0)  //safe check if that user dont exist in db
            {
                return View("~/Views/Admin/IncorrectLogin.cshtml");
            }

            string UserDBPassword = query.Single(); //make it single(query contains in iquery list so make it single and convert it in single string)
            if (Password == UserDBPassword)
            {
                AdminSessionID = AdminId;  //update session id

                return RedirectToAction("LogIn");

                //return View();   //Login Landing page
                //return Redirect("Item/Index");
            }
            else
            {
                return View("~/Views/Admin/IncorrectLogin.cshtml");
                //return RedirectToAction("LandingPage");
            }

            //if (UserId=="nabeelnoor914@gmail" && Password == "1234")
            //{
            //    return View();   //Login Landing page
            //}
            //else
            //{
            //    return View("~/Views/User/IncorrectLogin.cshtml");
            //    //return RedirectToAction("LandingPage");
            //}
        }


        public IActionResult LogIn()
        {
            DatabaseContextTest obj = new DatabaseContextTest();
            //{
            var query = from item in obj.Item
                        select item;
            //}
            return View(query);

            //return View();
            //return View();
        }
    }
}
