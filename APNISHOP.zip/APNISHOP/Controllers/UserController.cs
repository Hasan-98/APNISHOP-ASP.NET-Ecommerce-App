﻿using APNISHOP.Database;
using APNISHOP.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace APNISHOP.Controllers
{
    
    public class UserController : Controller
    {
        public static string UserSessionID = "\0";


        [Route("User/Index")]
        [Route("User")]
        public IActionResult Index()
        {

            DatabaseContextTest obj = new DatabaseContextTest();
            //{
               var query = from user in obj.User
                            select user;
            //}
            return View(query);
        }

        public IActionResult Create()
        {
            return View();
        }

        public IActionResult CreateError()
        {
            return View();
        }

        public IActionResult Edit()
        {
            DatabaseContextTest obj = new DatabaseContextTest();

            var query = obj.User
                        .Where(name => name.UserId == UserSessionID)
                        .Select(name => name);  //can be single or 0

            User temp = query.Single();
            return View(temp);
        }
        public IActionResult Details()
        {
            DatabaseContextTest obj = new DatabaseContextTest();

            var query = obj.User
                        .Where(name => name.UserId == UserSessionID)
                        .Select(name => name);  //can be single or 0
            //if (query.Count() <= 0)  //safe check if that user dont exist in db
            //{
            //    return View("~/Views/User/IncorrectLogin.cshtml");
            //}

            //string UserDBPassword = query.Single(); //make it single(query contains in iquery list so make it single and convert it in single string)
            //if (Password == UserDBPassword)
            //{
            //    return View();   //Login Landing page
            //    return Redirect("Item/Index");
            //}
            User temp = query.Single();
            return View(temp);
        }
        
        public IActionResult LogOut()
        {
            UserSessionID = "\0";
            return RedirectToAction("Index","Home",new { area = "" } );//RedirectToRoute("Home/Index");
        }
        public IActionResult LandingPage()
        {
            return View();  //login page with registeration option to register.
        }

        public IActionResult LogIn()
        {
            DatabaseContextTest obj = new DatabaseContextTest();
            //{
            var query = from item in obj.Item
                        select item;
            //}
            return View(query);

            //return View();
        }

        [HttpPost]
        public IActionResult Update(User UpdatedData)
        {
            DatabaseContextTest obj = new DatabaseContextTest();

            var query = obj.User.SingleOrDefault(name => name.UserId == UserSessionID);
            if (query != null)
            {
                query.Name = UpdatedData.Name;
                query.Password = UpdatedData.Password;
                query.Contact = UpdatedData.Contact;
                obj.SaveChanges();
            }

            return RedirectToAction("LogIn");
                        //.Where(name => name.UserId == UserSessionID)
                        //.Select(name => name);  //can be single or 0

            //string UserDBPassword = query.Single(); //make it single(query contains in iquery list so make it single and convert it in single string)
            //if (Password == UserDBPassword)
            //{
            //    UserSessionID = UserId;  //update session id

            //    return RedirectToAction("LogIn");

            //    //return View();   //Login Landing page
            //    //return Redirect("Item/Index");
            //}
            //else
            //{
            //    return View("~/Views/User/IncorrectLogin.cshtml");
            //    //return RedirectToAction("LandingPage");
            //}

        }

        [HttpPost]
        public IActionResult LogInValidate(string UserId,string Password)
        {
            //use for debuggin whether string is empty or not (Use same name as of label)
            //if(string.IsNullOrEmpty(UserId) && string.IsNullOrEmpty(Password))
            //{
            //    return View("~/Views/User/debug1.cshtml");
            //}

            DatabaseContextTest obj = new DatabaseContextTest();

            var query = obj.User
                        .Where(name => name.UserId == UserId)
                        .Select(name => name.Password);  //can be single or 0
            if (query.Count() <= 0)  //safe check if that user dont exist in db
            {
                return View("~/Views/User/IncorrectLogin.cshtml");
            }

            string UserDBPassword=query.Single(); //make it single(query contains in iquery list so make it single and convert it in single string)
            if (Password == UserDBPassword)
            {
                UserSessionID = UserId;  //update session id

                return RedirectToAction("LogIn");

                //return View();   //Login Landing page
                //return Redirect("Item/Index");
            }
            else
            {
                return View("~/Views/User/IncorrectLogin.cshtml");
                //return RedirectToAction("LandingPage");
            }

            //if (UserId=="nabeelnoor914@gmail" && Password == "1234")
            //{
            //    return View();   //Login Landing page
            //}
            //else
            //{
            //    return View("~/Views/User/IncorrectLogin.cshtml");
            //    //return RedirectToAction("LandingPage");
            //}
        }

        [HttpPost]
        public IActionResult Add(User obj)
        {
            bool CorrectStatus = true;
            using (DatabaseContextTest context=new DatabaseContextTest())
            {
                User temp = new User()
                {
                    UserId = obj.UserId,
                    Password=obj.Password,
                    Contact=obj.Contact,
                    Name=obj.Name,
                    ProfilePicture=obj.ProfilePicture

                };
                try
                {
                    context.User.Add(temp);
                    context.SaveChanges();
                }
                catch
                {
                    CorrectStatus = false;
                }

            }
            if (CorrectStatus == true)
            {
                return RedirectToAction("LandingPage");
                //return RedirectToAction("Index");
                
            }
            else {
                return RedirectToAction("CreateError");
            }
            
            
        }
    
        
    }
}
