﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace APNISHOP.Models
{
    public class BuyOrder
    {
        public string BuyOrderId { get; set; }

        public string Status { get; set; }

        public string Date { get; set; }
        public int Qty { get; set; }


        public User User { get; set; }

        public Item Item { get; set; }
    }
}
