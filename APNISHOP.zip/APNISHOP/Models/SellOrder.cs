﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace APNISHOP.Models
{
    public class SellOrder
    {
        public string SellOrderId { get; set; }

        public string ProductName { get; set; }
        
        public string Category { get; set; }
        
        public int Qty { get; set; }

        public int CostPerUnit { get; set; }

        public string Description { get; set; }
        public User User { get; set; }
    }
}
