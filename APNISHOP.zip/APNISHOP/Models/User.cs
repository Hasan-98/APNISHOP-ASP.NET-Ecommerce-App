﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace APNISHOP.Models
{
    public class User
    {
        [Key]
        public string UserId { get; set; }
        
       
        //public string UserIdI
        //{
        //    get { return UserId;  }
        //    set
        //    {
        //        if (value.Contains("@") && value.Contains(".com"))
        //        {
        //            UserId = value;
        //        }

                
        //    }
        //}

        public string Password
        {
            get;
            set;
        }

        public string Contact
        {
            get;
            set;
        }

        public string Name
        {
            get;
            set;
        }

        public string ProfilePicture
        {
            get;
            set;
        }

        public ICollection<BuyOrder> BuyOrder { get; set; }

        public ICollection<SellOrder> SellOrder { get; set; }

    }
}
