﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace APNISHOP.Models
{
    public class Item
    {
        public string ItemId { get; set; }
        public string Name { get; set; }
        public string Category { get; set; }
        public string Description { get; set; }
        public int Demand { get; set; }
        public int CurrentQuantity { get; set; }
        public int CostPerUnit { get; set; }

        private double rating;
        private double TotalPoints;
        private int PointsUser;

        public double Rating
        {
            get { return rating; }
            set
            {
                if(value>=0 && value <= 5)
                {
                    TotalPoints += value;
                    PointsUser++;
                    rating = (TotalPoints / PointsUser);
                }
            }
        }

        //public User User { get; set; }
    }
}
