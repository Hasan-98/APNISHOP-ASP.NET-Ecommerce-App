﻿using APNISHOP.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;

namespace APNISHOP.Database
{
    public class DatabaseContextTest : DbContext
    {
        public DatabaseContextTest() : base()
        {

        }

        //protected override void OnModelCreating(DbModelBuilder modelBuilder)
        //{
            
        //    //Database.SetInitializer<DbContext>(null);
        //    base.OnModelCreating(modelBuilder);
        //}

        public DbSet<User> User { get; set; }
        public DbSet<Item> Item { get; set; }
        public DbSet<Admin> Admin { get; set; }
    
        public DbSet<SellOrder> SellOrder { set; get; }

        public DbSet<BuyOrder> BuyOrder { set; get; }
    }
}
